Select p1.project, count(distinct p1.empID) from Projects p1
group by p1.project
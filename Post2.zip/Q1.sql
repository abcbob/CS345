Select distinct month from Sales 
inner join Product on Sales.pname =Product.pname
inner join Company on Product.manufacturer = Company.cname
where Company.country ='Korea';
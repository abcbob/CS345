select Sales.pname, Sales.month from Sales 
inner join (
    select pname, max(sold) as max from Sales
    group by pname
) as MSales on Sales.pname = MSales.pname and Sales.sold = max;
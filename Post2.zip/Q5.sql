Select Product.category, count(distinct Company.country) from Product
left join Company on Product.manufacturer=Company.cname
group by product.category
Select e1.name,e2.name from Employees e1
left join Employees e2 on e2.empID = e1.managerID;
Select Sales.pname,sum(Sales.sold) from Sales
group by sales.pname
having sum(Sales.sold)>2; 
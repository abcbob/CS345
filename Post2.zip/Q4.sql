Select Company.country, count(Product.category)
from Company inner join Product on Company.cname =Product.manufacturer
where (Product.category='Gadgets')
Group by (Company.country);
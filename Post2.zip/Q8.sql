SELECT COUNT(pname), category
FROM Product
GROUP BY category
having COUNT(pname) >= 2;
create table B(
    c int, 
    d int, 
    primary key(c));
create table D(
    g int, 
    h int, 
    primary key(g));
create table A(
    a int,
    b int,
    c int,
    primary key(a,c),
    foreign key (c) references B(c));
create table C(
    a int,
    c int,
    e int,
    primary key (a,c), 
    foreign key(a,c) references A(a,c));
create table S(
    f int, 
    a int, 
    c int,
    g int, 
    primary key (a,c,g), 
    foreign key (a,c) references C(a,c), 
    foreign key (g) references D(g));
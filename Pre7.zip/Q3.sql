create table r1 as
(Select B,A from R);
create table r2 as
(Select C,D,E from R);
create table r3 as
(Select B,C,D from R);
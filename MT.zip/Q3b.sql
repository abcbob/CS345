create table Grants(
    gid varchar(20),
    source varchar(20),
    orgName varchar(20),
    year varchar(20),
    primary key (gid,orgName),
    foreign key (orgName) references University(orgName)
);
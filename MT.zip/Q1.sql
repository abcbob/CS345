CREATE TABLE Courses (
    courseID integer,
    title varchar(50),
    enrollment integer check(enrollment<=200),
    classroom varchar(50) not null,
    prereqID integer,
    primary key(courseID),
    foreign key (prereqID) references Courses(courseID),
    check(prereqID<>courseID)
);
create table Department(
    orgName varchar(20),
    deptName varchar(20),
    address varchar(20),
    primary key (orgName,deptName),
    foreign key (orgName) references Organization(orgName)
);
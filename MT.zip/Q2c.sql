Select Project.pid, Project.name from Project
where Project.pid not in 
(Select pid from WorksOn where WorksOn.year>=2008);
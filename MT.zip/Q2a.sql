Select count(distinct did) from WorksOn
join Project on Project.pid= WorksOn.pid
where WorksOn.year<Project.releaseYear;
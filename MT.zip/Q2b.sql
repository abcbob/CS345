Select Project.pid, count(distinct WorksOn.did) from Project
left join WorksOn on Project.pid = WorksOn.pid
group by Project.pid;
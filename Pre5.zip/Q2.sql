create table article(
    id varchar(10) primary key,
    journal varchar(10),
    volume varchar(10),
    number varchar(10),
    foreign key (id) references publication(id)
);
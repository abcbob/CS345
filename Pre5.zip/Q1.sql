create table makes(
    pname varchar(10),
    category varchar(10),
    cname varchar(10),
    year varchar(10),
    primary key (pname, category),
    foreign key (pname, category) references product(pname,category),
    foreign key (cname) references company(cname)
);
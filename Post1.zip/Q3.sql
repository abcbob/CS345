select distinct Company.cname from Company left join Product ON Company.cname = Product.manufacturer
where Company.country='Japan' and Product.category= 'Photography';
Select Employees.name from Employees
inner join Projects p1 on Employees.empID = p1.empID
inner join Projects p2 on Employees.empID = p2.empID
where p1.project = 'Web archive' and p2.project = 'Phone app'
order by Employees.name asc;
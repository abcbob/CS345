Select Product.pname from Product left join Company on Product.manufacturer= Company.cname 
WHERE Company.country ='Japan'
Order by Product.pname;
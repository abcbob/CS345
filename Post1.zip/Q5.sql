Select Employees.name, Projects.project from Employees
inner join Projects on Employees.empID=Projects.empID
Order by Employees.name asc, Projects.project asc;
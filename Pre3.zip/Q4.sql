Select count(distinct a1.id) from casts c1
inner join actor a1 on a1.id= c1.pid
inner join movie m1 on m1.id = c1.mid
inner join casts c2 on a1.id= c2.pid
inner join movie m2 on m2.id = c2.mid
where m1.year = '1995' and m2.year='2010';
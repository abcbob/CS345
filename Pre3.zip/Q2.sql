Select count( casts.role) from casts
inner join actor on actor.id=casts.pid
inner join movie on movie.id = casts.mid
where movie.name = 'The Shawshank Redemption';
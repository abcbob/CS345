Select count(distinct actor.id) from casts
inner join actor on actor.id=casts.pid
inner join movie on movie.id = casts.mid
where movie.year = '1995';
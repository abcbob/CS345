Select distinct movie.name from movie
inner join movie_directors on movie_directors.mid=movie.id
inner join directors on directors.id = movie_directors.did
where directors.fname = 'Frank' and directors.lname ='Darabont';
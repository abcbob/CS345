Select count(distinct tbl.a) from 
(select actor.id as a from casts
inner join actor on actor.id=casts.pid
group by casts.mid, actor.id
having count(actor.id) >= 2) tbl;

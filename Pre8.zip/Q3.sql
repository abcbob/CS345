create view i as
select p2.name from Person p1
inner join Relationship r on p1.pid=r.pid1
inner join Person p2 on r.pid2=p2.pid
where p1.name='India' and r.rel='friend';
grant select on i to India; 
create view mutual as
Select distinct(p1.name as name1, p2.name as name2) from Person p1
inner join Relationship r1 on p1.pid=r1.pid1 and r1.rel='friend'
inner join Person p2 on p2.pid=r1.pid2
inner join Relationship r2 on p2.pid=r2.pid1 and r2.pid2=p1.pid and r2.rel='friend'
where p1.pid<p2.pid;
create table S1 as(
    select D,E from S
);
create table S2 as(
    select C,F,G from S
);
create table S3 as(
    select  A,C,D from S
);
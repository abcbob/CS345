create table T(
    A int,
    B int,
    C int,
    D int,
    E int,
    Primary key (A,C)
)
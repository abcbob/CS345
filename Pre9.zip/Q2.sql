create table S(
    A int,
    B int,
    C int,
    D int,
    E int,
    F int,
    G int,
    primary key(D)
)
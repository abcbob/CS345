insert into X(A,B,C) values(1,2,3);
insert into X(A,B,C) values(2,3,2);
insert into X(A,B,C) values(3,3,3);
create table R(
    A int,
    B int,
    C int,
    D int,
    E int,
    primary key(A,E)
);
SELECT * from Product
Where pname Like'%Gizmo%';

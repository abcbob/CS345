SELECT * from Product
Where category = 'Gadgets';
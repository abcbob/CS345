CREATE TABLE customer (
    fname VARCHAR(50),
    lname VARCHAR(50),
    phone VARCHAR(20)
);
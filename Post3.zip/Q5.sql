select max(cnt) from (
    select count(*) as cnt from movie_directors md
    inner join genre g on md.mid = g.mid
    where g.genre = 'Thriller'
    group by md.did
) tbl;
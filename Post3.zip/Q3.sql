select directors.fname, directors.lname, count(*) from directors
inner join movie_directors md on directors.id = md.did
inner join genre g on md.mid = g.mid
where g.genre = 'Thriller'
group by directors.fname, directors.lname
having count(*) >= 40
order by count(*) desc;
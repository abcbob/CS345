select actor.fname, actor.lname, count(distinct casts.mid) from actor
inner join casts on actor.id = casts.pid
inner join movie on movie.id = casts.mid
inner join genre g on movie.id = g.mid
where g.genre = 'Thriller'
group by actor.fname, actor.lname
having count(distinct casts.mid) >= 40
order by count(distinct casts.mid) desc;
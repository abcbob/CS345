Select count(*) from movie
where movie.year = 1890;
select a.fname, a.lname, m.name as movie from actor a
join casts c on a.id = c.pid
join movie m on c.mid = m.id
where m.year = 1990
group by a.fname, a.lname, m.name
having count(distinct c.role) = 5;
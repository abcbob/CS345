Select movie.year,count(*) from movie
where movie.year >= 1890 and movie.year<=1899
group by movie.year
order by movie.year asc;
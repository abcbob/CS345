Select count(*) from city
join country on country.code =city.countrycode
where country.governmentform = 'Territory of Australia';
Select m.year from movie m
group by m.year
order by count(*) desc
limit 1;
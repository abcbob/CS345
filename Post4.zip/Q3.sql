Select city.name from city
join countrylanguage on city.countrycode = countrylanguage.countrycode
group by city.name,city.population
having count(countrylanguage.language)=11
order by city.population desc
limit 1;
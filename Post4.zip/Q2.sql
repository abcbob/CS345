Select count (distinct a.id) from author a
join authored au on au.id = a.id
join article ar on ar.pubid = au.pubid
where ar.month ='January' and a.homepage is null;
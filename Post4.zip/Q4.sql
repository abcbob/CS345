Select a.fname, a.lname from actor a
join casts on casts.pid = a.id
join movie on movie.id = casts.mid
where movie.year = 2000
group by a.id,a.fname,a.lname
order by count(distinct movie.id) desc
limit 1;
Select count(distinct country.code) from country
left join countrylanguage on country.code = countrylanguage.countrycode and countrylanguage.isOfficial='T'
where country.continent = 'South America' and countrylanguage.language is null;

Select Employees.name from Employees
left join Projects on Employees.empID=Projects.empID
Group by Employees.name
having count(distinct Projects.project) >= 2;
SELECT category,AVG(price) AS price
FROM Product
Group by category;
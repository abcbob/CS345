select distinct Company.country from Company
inner join Product on Company.cname = Product.manufacturer
inner join Sales on Product.pname = Sales.pname
WHERE Sales.month = 'June';
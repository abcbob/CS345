Select category, Avg(price) from Product
where price<150
group by category;